﻿using System.Collections;
using DALayer;
using DALayer.Models;
using Microsoft.AspNetCore.Mvc;
using PersistentLayer.Repository;

namespace DotNetCore_Mongo.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly ProductRepository _repo;

        public ValuesController(IDbConfig config)
        {
            _repo = new ProductRepository(config);
        }

        // GET api/values
        [HttpGet]
        public IEnumerable Get()
        {
            return _repo.ShowAllProducts();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ProductModel Get(int id)
        {
            return _repo.ShowProductById(id);
        }

        // POST api/values
        [HttpPost]
        public bool Post(ProductModel product)
        {
            return _repo.AddProduct(product);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public bool Delete(int id)
        {
            return _repo.RemoveProduct(id);
        }
    }
}