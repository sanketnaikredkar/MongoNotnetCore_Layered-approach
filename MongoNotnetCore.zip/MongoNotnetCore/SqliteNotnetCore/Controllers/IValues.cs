﻿using System.Collections;
using DALayer.Models;

namespace DotNetCoreAPI.Controllers
{
    public interface IValues
    {
        bool Delete(int id);
        IEnumerable Get();
        ProductModel Get(int id);
        bool Post(ProductModel product);
    }
}