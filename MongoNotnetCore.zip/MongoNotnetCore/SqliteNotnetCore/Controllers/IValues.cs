﻿using System.Collections;
using DALayer.Models;

namespace DotNetCore_Mongo.Controllers
{
    public interface IValues
    {
        bool Delete(int id);
        IEnumerable Get();
        ProductModel Get(int id);
        bool Post(ProductModel product);
    }
}