﻿using DALayer;
using Microsoft.Extensions.Configuration;

namespace DotNetCore_Mongo.DbConfig
{
    public class DbConfig : IDbConfig
    {
        private readonly string _connectionString;
        private readonly string _dbName;

        public DbConfig(IConfiguration iConfig)
        {
            _connectionString = iConfig.GetSection("DbConfig").GetSection("ConnectionString").Value;
            _dbName = iConfig.GetSection("DbConfig").GetSection("DbName").Value;
        }

        public string ConnectionString
        {
            get => _connectionString;
            set => value = _connectionString;
        }

        public string DbName
        {
            get => _dbName;
            set => value = _dbName;
        }
    }
}