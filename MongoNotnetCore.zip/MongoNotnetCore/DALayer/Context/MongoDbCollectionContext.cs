﻿using System;
using DALayer.Models;
using MongoDB.Driver;

namespace DALayer.Context
{
    public class MongoDbCollectionContext : IMongoDbCollectionContext
    {
        private IMongoDatabase Database { get; }
        public MongoDbCollectionContext(IDbConfig config)
        {
            try
            {
                var settings = MongoClientSettings.FromUrl(new MongoUrl(config.ConnectionString));
                MongoClient mongodbClient = new MongoClient(settings);
                Database = mongodbClient.GetDatabase(config.DbName);
            }
            catch (Exception ex)
            {
                throw new Exception("Can not access to db server.", ex);
            }
        }

        public IMongoCollection<ProductModel> ProductsCollection => Database.GetCollection<ProductModel>("Products");
    }
}