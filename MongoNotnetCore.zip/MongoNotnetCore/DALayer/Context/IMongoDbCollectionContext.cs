﻿using DALayer.Models;
using MongoDB.Driver;

namespace DALayer.Context
{
    public interface IMongoDbCollectionContext
    {
        IMongoCollection<ProductModel> ProductsCollection { get; }
    }
}