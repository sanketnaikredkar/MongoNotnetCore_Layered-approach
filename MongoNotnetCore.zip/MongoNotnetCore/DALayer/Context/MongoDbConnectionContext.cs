﻿using System;
using DALayer.Models;
using MongoDB.Driver;

namespace DALayer.Context
{
    public class MongoDbConnectionContext
    {
        public MongoDbConnectionContext(IDbConfig config)
        {
            _config = config;
            try
            {
                var settings = MongoClientSettings.FromUrl(new MongoUrl(_config.ConnectionString));
                var mongoClient = new MongoClient(settings);
                _database = mongoClient.GetDatabase(_config.DbName);
            }
            catch (Exception ex)
            {
                throw new Exception("Can not access to db server.", ex);
            }
        }

        private IDbConfig _config { get; }
        private IMongoDatabase _database { get; }

        public IMongoCollection<ProductModel> ProductsCollection => _database.GetCollection<ProductModel>("Products");
    }
}