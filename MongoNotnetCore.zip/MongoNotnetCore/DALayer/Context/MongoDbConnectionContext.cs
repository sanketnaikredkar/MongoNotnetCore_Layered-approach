﻿using System;
using DALayer.Models;
using MongoDB.Driver;

namespace DALayer.Context
{
    public class MongoDbConnectionContext
    {
        private IMongoDatabase _database { get; }
        public MongoDbConnectionContext(IDbConfig config)
        {
            try
            {
                var settings = MongoClientSettings.FromUrl(new MongoUrl(config.ConnectionString));
                var mongoClient = new MongoClient(settings);
                _database = mongoClient.GetDatabase(config.DbName);
            }
            catch (Exception ex)
            {
                throw new Exception("Can not access to db server.", ex);
            }
        }

        

        public IMongoCollection<ProductModel> ProductsCollection => _database.GetCollection<ProductModel>("Products");
    }
}