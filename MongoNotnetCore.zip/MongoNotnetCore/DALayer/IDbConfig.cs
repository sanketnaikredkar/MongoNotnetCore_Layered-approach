﻿namespace DALayer
{
    public interface IDbConfig
    {
        string ConnectionString { get; set; }
        string DbName { get; set; }
    }
}