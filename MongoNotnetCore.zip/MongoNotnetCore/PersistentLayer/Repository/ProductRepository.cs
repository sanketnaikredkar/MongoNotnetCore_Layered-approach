﻿using DALayer;
using DALayer.Context;
using DALayer.Models;
using MongoDB.Driver;
using PersistentLayer.Interfaces;
using System.Collections.Generic;

namespace PersistentLayer.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly IMongoDbCollectionContext _context;

        public ProductRepository(IDbConfig config, IMongoDbCollectionContext context)
        {
            _context = context;
        }
        
        public IEnumerable<ProductModel> ShowAllProducts()
        {
            return _context.ProductsCollection.Find(r => true).ToList();
        }

        public ProductModel ShowProductById(int id)
        {
            return _context.ProductsCollection.Find(i => i.ProductId == id).FirstOrDefault();
        }

        public bool AddProduct(ProductModel product)
        {
            _context.ProductsCollection.InsertOne(product);
            return true;
        }

        public bool RemoveProduct(int id)
        {
            var save = _context.ProductsCollection.DeleteOne(row => row.ProductId == id);
            return save.DeletedCount > 0 ? true : false;
        }

        public bool UpdateProduct(ProductModel product)
        {
            var save = _context.ProductsCollection.ReplaceOne(row => row.ProductId == product.ProductId, product);
            return save.IsModifiedCountAvailable;
        }
    }
}