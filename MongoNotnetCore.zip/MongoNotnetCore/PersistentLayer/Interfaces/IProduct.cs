﻿using System.Collections.Generic;
using DALayer.Models;

namespace PersistentLayer.Interfaces
{
    public interface IProduct
    {
        IEnumerable<ProductModel> ShowAllProducts();
        ProductModel ShowProductById(int id);
        bool AddProduct(ProductModel product);
        bool RemoveProduct(int id);
        bool UpdateProduct(ProductModel product);
    }
}